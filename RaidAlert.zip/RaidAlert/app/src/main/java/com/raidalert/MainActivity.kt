package com.raidalert

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButtonToggleGroup

class MainActivity : AppCompatActivity() {

    companion object {
        private const val DESC_BASIC =
            "Обычные уведомления со звуком и вибрацией. Если на телефоне беззвучный режим или «Не беспокоить», сигнала не будет."
        private const val DESC_EXTREME =
            "Как будильник: громкий сигнал по кругу даже в беззвучном режиме, непрерывная вибрация, громкость будильника на максимум, экран включается поверх блокировки. Продолжается до кнопки «Стоп» или до конца серии, потом громкость возвращается."
    }

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var modeGroup: MaterialButtonToggleGroup
    private lateinit var modeDesc: TextView
    private lateinit var etPackage: EditText
    private lateinit var etKeywords: EditText
    private lateinit var etTitle: EditText
    private lateinit var etBody: EditText
    private lateinit var etInterval: EditText
    private lateinit var etCount: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        status = findViewById(R.id.status)
        log = findViewById(R.id.log)
        modeGroup = findViewById(R.id.modeGroup)
        modeDesc = findViewById(R.id.modeDesc)
        etPackage = findViewById(R.id.etPackage)
        etKeywords = findViewById(R.id.etKeywords)
        etTitle = findViewById(R.id.etTitle)
        etBody = findViewById(R.id.etBody)
        etInterval = findViewById(R.id.etInterval)
        etCount = findViewById(R.id.etCount)

        etPackage.setText(prefs.gamePackage)
        etKeywords.setText(prefs.keywords)
        etTitle.setText(prefs.title)
        etBody.setText(prefs.body)
        etInterval.setText(prefs.intervalMs.toString())
        etCount.setText(prefs.count.toString())

        modeGroup.check(if (prefs.extreme) R.id.modeExtreme else R.id.modeBasic)
        updateModeDesc()
        modeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                prefs.extreme = (id == R.id.modeExtreme)
                updateModeDesc()
            }
        }

        findViewById<TextView>(R.id.tiktok).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@do_not_stress187")))
            } catch (_: Exception) {
            }
        }

        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        val fullBlock = findViewById<View>(R.id.fullBlock)
        if (Build.VERSION.SDK_INT < 34) fullBlock.visibility = View.GONE
        findViewById<Button>(R.id.btnFull).setOnClickListener {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            } catch (_: Exception) {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            }
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            save()
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            save()
            Spammer.start(this)
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { Spammer.stop(this) }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refresh() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            prefs.clearLog()
            refresh()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    private fun updateModeDesc() {
        modeDesc.text = if (prefs.extreme) DESC_EXTREME else DESC_BASIC
    }

    private fun save() {
        prefs.gamePackage = etPackage.text.toString()
        prefs.keywords = etKeywords.text.toString()
        prefs.title = etTitle.text.toString()
        prefs.body = etBody.text.toString()
        prefs.intervalMs = etInterval.text.toString().toLongOrNull() ?: 1500L
        prefs.count = etCount.text.toString().toIntOrNull() ?: 60
    }

    private fun refresh() {
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        status.text = if (enabled) "●  ДОСТУП К УВЕДОМЛЕНИЯМ ВЫДАН" else "●  ДОСТУП К УВЕДОМЛЕНИЯМ НЕ ВЫДАН"
        status.setTextColor(ContextCompat.getColor(this, if (enabled) R.color.fg else R.color.bad))
        val l = prefs.getLog()
        log.text = if (l.isEmpty()) "Лог пуст" else l
    }
}
