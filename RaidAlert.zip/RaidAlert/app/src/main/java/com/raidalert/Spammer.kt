package com.raidalert

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Spammer {
    private const val CH_BASIC = "raid_basic"
    private const val CH_EXTREME = "raid_extreme"
    private const val BASE_ID = 1000

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var sent = 0
    private var total = 0

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var savedVolume = -1

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        if (running) return
        val prefs = Prefs(app)
        running = true
        sent = 0
        total = prefs.count
        ensureChannels(app)
        if (prefs.extreme) startAlarm(app)
        handler.post(object : Runnable {
            override fun run() {
                if (!running) return
                if (sent >= total) {
                    running = false
                    stopAlarm(app)
                    return
                }
                post(app, prefs, sent)
                sent++
                handler.postDelayed(this, prefs.intervalMs)
            }
        })
    }

    fun stop(ctx: Context) {
        val app = ctx.applicationContext
        running = false
        handler.removeCallbacksAndMessages(null)
        stopAlarm(app)
        val nm = NotificationManagerCompat.from(app)
        for (i in 0 until maxOf(total, sent)) nm.cancel(BASE_ID + i)
    }

    // Extreme: громкость будильника на максимум, сигнал по кругу, вибрация по кругу
    private fun startAlarm(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            savedVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(
                AudioManager.STREAM_ALARM,
                am.getStreamMaxVolume(AudioManager.STREAM_ALARM),
                0
            )
        } catch (_: Exception) {
        }

        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(ctx, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (_: Exception) {
            player = null
        }

        try {
            @Suppress("DEPRECATION")
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator = v
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 400), 0))
        } catch (_: Exception) {
        }
    }

    private fun stopAlarm(ctx: Context) {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null

        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        vibrator = null

        if (savedVolume >= 0) {
            try {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0)
            } catch (_: Exception) {
            }
            savedVolume = -1
        }
        AlarmActivity.instance?.finish()
    }

    private fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.deleteNotificationChannel("raid_alarm")

        if (nm.getNotificationChannel(CH_BASIC) == null) {
            val ch = NotificationChannel(CH_BASIC, "Рейд: режим Basic", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Обычные уведомления о рейде"
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            ch.setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            nm.createNotificationChannel(ch)
        }

        if (nm.getNotificationChannel(CH_EXTREME) == null) {
            val ch = NotificationChannel(CH_EXTREME, "Рейд: режим Extreme", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Тревога как будильник. Звук и вибрацию ведёт само приложение"
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setBypassDnd(true)
            nm.createNotificationChannel(ch)
        }
    }

    @SuppressLint("MissingPermission")
    private fun post(ctx: Context, prefs: Prefs, n: Int) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return

        val extreme = prefs.extreme
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        val stop = PendingIntent.getBroadcast(ctx, 1, Intent(ctx, StopReceiver::class.java), flags)

        val b = NotificationCompat.Builder(ctx, if (extreme) CH_EXTREME else CH_BASIC)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(prefs.title)
            .setContentText(prefs.body)
            .setSubText("Stress")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(if (extreme) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "СТОП", stop)

        if (extreme && n == 0) {
            val alarmIntent = Intent(ctx, AlarmActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val full = PendingIntent.getActivity(ctx, 2, alarmIntent, flags)
            b.setFullScreenIntent(full, true)
        }

        nm.notify(BASE_ID + n, b.build())
    }
}
