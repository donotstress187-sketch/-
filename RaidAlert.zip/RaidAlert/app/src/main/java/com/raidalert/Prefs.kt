package com.raidalert

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var gamePackage: String
        get() = sp.getString("pkg", "com.catsbit.oxidesurvivalisland") ?: ""
        set(v) = sp.edit().putString("pkg", v.trim()).apply()

    var keywords: String
        get() = sp.getString("kw", "атакована,атак,raid,рейд,attack") ?: ""
        set(v) = sp.edit().putString("kw", v).apply()

    var title: String
        get() = sp.getString("title", "РЕЙД. ВСТАВАЙ.") ?: ""
        set(v) = sp.edit().putString("title", v).apply()

    var body: String
        get() = sp.getString("body", "Тебя рейдят в Oxide. Иди на базу.") ?: ""
        set(v) = sp.edit().putString("body", v).apply()

    var intervalMs: Long
        get() = sp.getLong("interval", 1500L)
        set(v) = sp.edit().putLong("interval", v.coerceAtLeast(300L)).apply()

    var count: Int
        get() = sp.getInt("count", 60)
        set(v) = sp.edit().putInt("count", v.coerceIn(1, 500)).apply()

    var extreme: Boolean
        get() = sp.getString("mode", "basic") == "extreme"
        set(v) = sp.edit().putString("mode", if (v) "extreme" else "basic").apply()

    fun addLog(line: String) {
        val clean = line.replace('\n', ' ')
        val lines = getLog().split('\n').filter { it.isNotBlank() }.toMutableList()
        lines.add(0, clean)
        sp.edit().putString("log", lines.take(30).joinToString("\n")).apply()
    }

    fun getLog(): String = sp.getString("log", "") ?: ""

    fun clearLog() = sp.edit().remove("log").apply()
}
